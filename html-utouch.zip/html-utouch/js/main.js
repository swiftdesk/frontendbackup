var _0x4b77 = ["use strict", "body", "#site-header", "#site-footer", ".counter", ".countdown-timer", ".skills-item", "#primary-menu", "#hellopreloader", ".cd-overlay-nav", ".cd-overlay-content", ".cd-primary-nav", ".cd-nav-trigger", "toggleNav", "close-nav", "hasClass", "addClass", "easeInCubic", "fade-in", "velocity", "span", "children", "removeClass", "webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend", "is-hidden", "one", "no-csstransitions", "html", "layerInit",
    "height", "pow", "width", "sqrt", "px", "fixedHeader", "animated", "slideDown", "slideUp", "headroom", "parallaxFooter", "length", "js-fixed-footer", '<div class="block-footer-height"></div>', "before", "matchHeight", ".block-footer-height", "preloader", "scrollTop", "fadeOut", "smoothScroll", "function", 'a[href*="#"]', "[data-toggle]", "Protection", "hostname", "test", "innerHTML", "getElementsByTagName", '<div style="margin:50px auto;width:600px;text-align:center"><h1 style="font-size:50px;">Great! You like my template!</h1><div style="font-size:30px;"><a href="https://goo.gl/gmMgeh">Please purchase it</a> if you\'d like to use it further</div> <p>or delete my tracking code if you wan\'t to get rid of this message and use it illegally :(</p></div>',
    "counters", "countTo", "find", "element", "destroy", "95%", "waypoint", "each", "countdown", "data", "update.countdown", "", '<div class="column"><div class="text">DAY%!d</div><div class="timer">%D</div></div><div class="timer">:</div>', '<div class="column"><div class="text">HRS</div><div class="timer">%H</div></div><div class="timer">:</div>', '<div class="column"><div class="text">MIN</div><div class="timer">%M</div></div><div class="timer">:</div>', '<div class="column"><div class="text">SEC</div><div class="timer">%S</div></div>',
    "strftime", "on", "progresBars", ".count-animate", "skills-animate", "fadeTo", ".skills-item-meter-active", "90%", "toggleSearch", "open", "toggleClass", ".search-popup", "focus", ".search-full-screen input", "mediaPopups", "iframe", "mfp-fade", "magnificPopup", ".js-popup-iframe", "image", "markup", "st", "mfp-figure", "mfp-figure mfp-with-anim", "replace", "mainClass", "mfp-zoom-in", ".js-zoom-image, .link-image", "equalHeight", "min-height", ".theme-module", ".js-equal-child", "IsotopeSort", ".sorting-container",
    "layout", "masonry", ".sorting-item", "isotope", "progress", "imagesLoaded", "li", ".sorting-menu", "siblings", "click", "active", ".active", "parent", "filter", "undefined", "initSwiper", "swiper-unique-id-", "id", "attr", "swiper-", " initialized", "pagination-", ".swiper-pagination", ".crumina-module", "closest", "effect", "slide", "crossfade", "loop", "show-items", "scroll-items", "direction", "horizontal", "mouse-scroll", "autoplay", "auto-height", "nospace", "centered-slider", "stretch", "depth",
    ".swiper-", ".pagination-", ".slider-slides", "slide-active", ".slider-slides .slide-active", "data-swiper-slide-index", "activeIndex", "eq", "slides", ".slider-slides .slides-item", ".swiper-container", ".crumina-module-slider", "slidePrev", ".btn-prev", "slideNext", ".btn-next", "preventDefault", "index", ".slides-item", "slideTo", ".slide-active", "burgerAnimation", "80% - 240", "80%", "draw", "100% - 545", "100% - 305", "elastic-out", "ease", "bounce-out", "90% - 240", "elastic-in", "20% - 240",
    "20%", "className", "menu-icon-wrapper scaled", "menu-icon-wrapper", "pathD", "getElementById", "pathE", "pathF", "menu-icon-trigger", "visibility", "style", "visible", "onclick", "which", "overlay-enable", ".search-standard", "css", "1", "#menu-icon-trigger", ".top-bar", "keydown", ".js-open-search-popup > *", ".overlay_search-close", "#top-bar-js", "hidden", "0", ".search-input", ".js-open-search-standard > *", ".js-search-close > *", "#top-bar-close-js", ".message-popup", ".js-message-popup",
    ".popup-gallery", ".js-popup-close", "val", "input", ".js-popup-clear-input", ".panel-heading", "parents", ".accordion-panel", ".accordion-heading", "animate", "html,body", ".back-to-top", ".share-product", ".social__item.main", "hover", "mouseleave", ":checked", "is", "prev", ".crumina-pricings", ".price", "annually", "text", "monthly", ".js-pricing-switcher", "#menu-icon-wrapper", "drop-up", "&#xf0d7", "&#xf105", "crumegamenu", "niceSelect", "select", "ready", "resize", "requestAnimationFrame"
];
var CRUMINA = {};
(function(_0xa2c4x2) {
    _0x4b77[0];
    var _0xa2c4x3 = _0xa2c4x2(window);
    var _0xa2c4x4 = _0xa2c4x2(document);
    var _0xa2c4x5 = _0xa2c4x2(_0x4b77[1]);
    var _0xa2c4x6 = {};
    var _0xa2c4x7 = _0xa2c4x2(_0x4b77[2]);
    var _0xa2c4x8 = _0xa2c4x2(_0x4b77[3]);
    var _0xa2c4x9 = _0xa2c4x2(_0x4b77[4]);
    var _0xa2c4xa = _0xa2c4x2(_0x4b77[5]);
    var _0xa2c4xb = _0xa2c4x2(_0x4b77[6]);
    var _0xa2c4xc = _0xa2c4x2(_0x4b77[7]);
    var _0xa2c4xd = _0xa2c4x2(_0x4b77[8]);
    var _0xa2c4xe = _0xa2c4x2(_0x4b77[9]);
    var _0xa2c4xf = _0xa2c4x2(_0x4b77[10]);
    var _0xa2c4x10 = _0xa2c4x2(_0x4b77[11]);
    var _0xa2c4x11 = _0xa2c4x2(_0x4b77[12]);
    CRUMINA[_0x4b77[13]] = function() {
        if (!_0xa2c4x11[_0x4b77[15]](_0x4b77[14])) {
            _0xa2c4x11[_0x4b77[16]](_0x4b77[14]);
            _0xa2c4xe[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
                translateZ: 0,
                scaleX: 1,
                scaleY: 1
            }, 500, _0x4b77[17], function() {
                _0xa2c4x10[_0x4b77[16]](_0x4b77[18]);
            });
        } else {
            _0xa2c4x11[_0x4b77[22]](_0x4b77[14]);
            _0xa2c4xf[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
                translateZ: 0,
                scaleX: 1,
                scaleY: 1
            }, 500, _0x4b77[17], function() {
                _0xa2c4x10[_0x4b77[22]](_0x4b77[18]);
                _0xa2c4xe[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
                    translateZ: 0,
                    scaleX: 0,
                    scaleY: 0
                }, 0);
                _0xa2c4xf[_0x4b77[16]](_0x4b77[24])[_0x4b77[25]](_0x4b77[23], function() {
                    _0xa2c4xf[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
                        translateZ: 0,
                        scaleX: 0,
                        scaleY: 0
                    }, 0, function() {
                        _0xa2c4xf[_0x4b77[22]](_0x4b77[24]);
                    });
                });
                if (_0xa2c4x2(_0x4b77[27])[_0x4b77[15]](_0x4b77[26])) {
                    _0xa2c4xf[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
                        translateZ: 0,
                        scaleX: 0,
                        scaleY: 0
                    }, 0, function() {
                        _0xa2c4xf[_0x4b77[22]](_0x4b77[24]);
                    });
                }
            });
        }
    };
    CRUMINA[_0x4b77[28]] = function() {
        var _0xa2c4x12 = Math[_0x4b77[32]](Math[_0x4b77[30]](_0xa2c4x2(window)[_0x4b77[29]](), 2) + Math[_0x4b77[30]](_0xa2c4x2(window)[_0x4b77[31]](), 2)) * 2;
        _0xa2c4xe[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
            scaleX: 0,
            scaleY: 0,
            translateZ: 0
        }, 50)[_0x4b77[19]]({
            height: _0xa2c4x12 + _0x4b77[33],
            width: _0xa2c4x12 + _0x4b77[33],
            top: -(_0xa2c4x12 / 2) + _0x4b77[33],
            left: -(_0xa2c4x12 / 2) + _0x4b77[33]
        }, 0);
        _0xa2c4xf[_0x4b77[21]](_0x4b77[20])[_0x4b77[19]]({
            scaleX: 0,
            scaleY: 0,
            translateZ: 0
        }, 50)[_0x4b77[19]]({
            height: _0xa2c4x12 + _0x4b77[33],
            width: _0xa2c4x12 + _0x4b77[33],
            top: -(_0xa2c4x12 / 2) + _0x4b77[33],
            left: -(_0xa2c4x12 / 2) + _0x4b77[33]
        }, 0);
    };
    CRUMINA[_0x4b77[34]] = function() {
        _0xa2c4x7[_0x4b77[38]]({
            "offset": 210,
            "tolerance": 5,
            "classes": {
                "initial": _0x4b77[35],
                "pinned": _0x4b77[36],
                "unpinned": _0x4b77[37]
            }
        });
    };
    CRUMINA[_0x4b77[39]] = function() {
        if (_0xa2c4x8[_0x4b77[40]] && _0xa2c4x8[_0x4b77[15]](_0x4b77[41])) {
            _0xa2c4x8[_0x4b77[43]](_0x4b77[42]);
            _0xa2c4x2(_0x4b77[45])[_0x4b77[44]]({
                target: _0xa2c4x8
            });
        }
    };
    CRUMINA[_0x4b77[46]] = function() {
        _0xa2c4x3[_0x4b77[47]](0);
        setTimeout(function() {
            _0xa2c4xd[_0x4b77[48]](800);
        }, 500);
        return false;
    };
    CRUMINA[_0x4b77[49]] = function() {
        if (typeof SmoothScroll === _0x4b77[50]) {
            var _0xa2c4x13 = new SmoothScroll(_0x4b77[51], {
                ignore: _0x4b77[52],
                header: _0x4b77[2],
                offset: 60
            })
        }
    };
    CRUMINA[_0x4b77[53]] = function() {
        if (/crumina\.net/ [_0x4b77[55]](location[_0x4b77[54]]) === false) {
            setTimeout(function() {
                document[_0x4b77[57]](_0x4b77[27])[0][_0x4b77[56]] = _0x4b77[58];
            }, 1E4);
        }
    };
    CRUMINA[_0x4b77[59]] = function() {
        if (_0xa2c4x9[_0x4b77[40]]) {
            _0xa2c4x9[_0x4b77[66]](function() {
                jQuery(this)[_0x4b77[65]](function() {
                    _0xa2c4x2(this[_0x4b77[62]])[_0x4b77[61]](_0x4b77[20])[_0x4b77[60]]();
                    this[_0x4b77[63]]();
                }, {
                    offset: _0x4b77[64]
                });
            });
        }
    };
    CRUMINA[_0x4b77[67]] = function() {
        if (_0xa2c4xa[_0x4b77[40]]) {
            _0xa2c4xa[_0x4b77[66]](function() {
                var _0xa2c4x14 = _0xa2c4x2(this);
                var _0xa2c4x15 = _0xa2c4x14[_0x4b77[68]](_0x4b77[67]);
                _0xa2c4x14[_0x4b77[67]](_0xa2c4x15)[_0x4b77[76]](_0x4b77[69], function(_0xa2c4x16) {
                    _0xa2c4x14[_0x4b77[27]](_0xa2c4x16[_0x4b77[75]](_0x4b77[70] + _0x4b77[71] + _0x4b77[72] + _0x4b77[73] + _0x4b77[74]));
                });
            });
        }
    };
    CRUMINA[_0x4b77[77]] = function() {
        if (_0xa2c4xb[_0x4b77[40]]) {
            _0xa2c4xb[_0x4b77[66]](function() {
                jQuery(this)[_0x4b77[65]](function() {
                    _0xa2c4x2(this[_0x4b77[62]])[_0x4b77[61]](_0x4b77[78])[_0x4b77[60]]();
                    _0xa2c4x2(this[_0x4b77[62]])[_0x4b77[61]](_0x4b77[81])[_0x4b77[80]](300, 1)[_0x4b77[16]](_0x4b77[79]);
                    this[_0x4b77[63]]();
                }, {
                    offset: _0x4b77[82]
                });
            });
        }
    };
    CRUMINA[_0x4b77[83]] = function() {
        setTimeout(function() {
            _0xa2c4x2(_0x4b77[86])[_0x4b77[85]](_0x4b77[84]);
        }, 300);
        _0xa2c4x2(_0x4b77[88])[_0x4b77[87]]();
    };
    CRUMINA[_0x4b77[89]] = function() {
        _0xa2c4x2(_0x4b77[93])[_0x4b77[92]]({
            disableOn: 700,
            type: _0x4b77[90],
            mainClass: _0x4b77[91],
            removalDelay: 160,
            preloader: false,
            fixedContentPos: false
        });
        _0xa2c4x2(_0x4b77[102])[_0x4b77[92]]({
            type: _0x4b77[94],
            removalDelay: 500,
            callbacks: {
                beforeOpen: function() {
                    this[_0x4b77[96]][_0x4b77[94]][_0x4b77[95]] = this[_0x4b77[96]][_0x4b77[94]][_0x4b77[95]][_0x4b77[99]](_0x4b77[97], _0x4b77[98]);
                    this[_0x4b77[96]][_0x4b77[100]] = _0x4b77[101];
                }
            },
            closeOnContentClick: true,
            midClick: true
        });
    };
    CRUMINA[_0x4b77[103]] = function() {
        _0xa2c4x2(_0x4b77[106])[_0x4b77[61]](_0x4b77[105])[_0x4b77[44]]({
            property: _0x4b77[104]
        });
    };
    CRUMINA[_0x4b77[107]] = function() {
        var _0xa2c4x17 = _0xa2c4x2(_0x4b77[108]);
        _0xa2c4x17[_0x4b77[66]](function() {
            var _0xa2c4x18 = _0xa2c4x2(this);
            var _0xa2c4x19 = _0xa2c4x18[_0x4b77[68]](_0x4b77[109])[_0x4b77[40]] ? _0xa2c4x18[_0x4b77[68]](_0x4b77[109]) : _0x4b77[110];
            _0xa2c4x18[_0x4b77[112]]({
                itemSelector: _0x4b77[111],
                layoutMode: _0xa2c4x19,
                percentPosition: true
            });
            _0xa2c4x18[_0x4b77[114]]()[_0x4b77[113]](function() {
                _0xa2c4x18[_0x4b77[112]](_0x4b77[109]);
            });
            var _0xa2c4x1a = _0xa2c4x18[_0x4b77[117]](_0x4b77[116])[_0x4b77[61]](_0x4b77[115]);
            _0xa2c4x1a[_0x4b77[76]](_0x4b77[118], function() {
                if (_0xa2c4x2(this)[_0x4b77[15]](_0x4b77[119])) {
                    return false;
                }
                _0xa2c4x2(this)[_0x4b77[121]]()[_0x4b77[61]](_0x4b77[120])[_0x4b77[22]](_0x4b77[119]);
                _0xa2c4x2(this)[_0x4b77[16]](_0x4b77[119]);
                var _0xa2c4x1b = _0xa2c4x2(this)[_0x4b77[68]](_0x4b77[122]);
                if (typeof _0xa2c4x1b != _0x4b77[123]) {
                    _0xa2c4x18[_0x4b77[112]]({
                        filter: _0xa2c4x1b
                    });
                    return false;
                }
            });
        });
    };
    CRUMINA[_0x4b77[124]] = function() {
        var _0xa2c4x1c = 0;
        _0xa2c4x2(_0x4b77[159])[_0x4b77[66]](function() {
            var _0xa2c4x1d = _0xa2c4x2(this);
            var _0xa2c4x1e = _0x4b77[125] + _0xa2c4x1c;
            var _0xa2c4x1f = false;
            _0xa2c4x1d[_0x4b77[16]](_0x4b77[128] + _0xa2c4x1e + _0x4b77[129])[_0x4b77[127]](_0x4b77[126], _0xa2c4x1e);
            _0xa2c4x1d[_0x4b77[133]](_0x4b77[132])[_0x4b77[61]](_0x4b77[131])[_0x4b77[16]](_0x4b77[130] + _0xa2c4x1e);
            var _0xa2c4x20 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[134]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[134]) : _0x4b77[135];
            var _0xa2c4x21 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[136]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[136]) : true;
            var _0xa2c4x22 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[137]) == false ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[137]) : true;
            var _0xa2c4x23 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[138]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[138]) : 1;
            var _0xa2c4x24 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[139]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[139]) : 1;
            var _0xa2c4x25 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[140]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[140]) : _0x4b77[141];
            var _0xa2c4x26 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[142]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[142]) : false;
            var _0xa2c4x27 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[143]) ? parseInt(_0xa2c4x1d[_0x4b77[68]](_0x4b77[143]), 10) : 0;
            var _0xa2c4x28 = _0xa2c4x1d[_0x4b77[15]](_0x4b77[144]) ? true : false;
            var _0xa2c4x29 = _0xa2c4x1d[_0x4b77[68]](_0x4b77[145]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[145]) : false;
            var _0xa2c4x2a = _0xa2c4x1d[_0x4b77[68]](_0x4b77[146]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[146]) : false;
            var _0xa2c4x2b = _0xa2c4x1d[_0x4b77[68]](_0x4b77[147]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[147]) : 0;
            var _0xa2c4x2c = _0xa2c4x1d[_0x4b77[68]](_0x4b77[148]) ? _0xa2c4x1d[_0x4b77[68]](_0x4b77[148]) : 0;
            var _0xa2c4x2d = _0xa2c4x23 > 1 && true != _0xa2c4x29 ? 20 : 0;
            if (_0xa2c4x23 > 1) {
                _0xa2c4x1f = {
                    480: {
                        slidesPerView: 1,
                        slidesPerGroup: 1
                    },
                    768: {
                        slidesPerView: 2,
                        slidesPerGroup: 2
                    }
                };
            }
            _0xa2c4x6[_0x4b77[128] + _0xa2c4x1e] = new Swiper(_0x4b77[149] + _0xa2c4x1e, {
                pagination: _0x4b77[150] + _0xa2c4x1e,
                paginationClickable: true,
                direction: _0xa2c4x25,
                mousewheelControl: _0xa2c4x26,
                mousewheelReleaseOnEdges: _0xa2c4x26,
                slidesPerView: _0xa2c4x23,
                slidesPerGroup: _0xa2c4x24,
                spaceBetween: _0xa2c4x2d,
                keyboardControl: true,
                setWrapperSize: true,
                preloadImages: true,
                updateOnImagesReady: true,
                centeredSlides: _0xa2c4x2a,
                autoplay: _0xa2c4x27,
                autoHeight: _0xa2c4x28,
                loop: _0xa2c4x22,
                breakpoints: _0xa2c4x1f,
                effect: _0xa2c4x20,
                fade: {
                    crossFade: _0xa2c4x21
                },
                parallax: true,
                onImagesReady: function(_0xa2c4x2e) {},
                coverflow: {
                    stretch: _0xa2c4x2b,
                    rotate: 0,
                    depth: _0xa2c4x2c,
                    modifier: 2,
                    slideShadows: false
                },
                onSlideChangeStart: function(_0xa2c4x2e) {
                    if (_0xa2c4x1d[_0x4b77[133]](_0x4b77[132])[_0x4b77[61]](_0x4b77[151])[_0x4b77[40]]) {
                        _0xa2c4x1d[_0x4b77[133]](_0x4b77[132])[_0x4b77[61]](_0x4b77[153])[_0x4b77[22]](_0x4b77[152]);
                        var _0xa2c4x2f = _0xa2c4x2e[_0x4b77[157]][_0x4b77[156]](_0xa2c4x2e[_0x4b77[155]])[_0x4b77[127]](_0x4b77[154]);
                        _0xa2c4x1d[_0x4b77[133]](_0x4b77[132])[_0x4b77[61]](_0x4b77[158])[_0x4b77[156]](_0xa2c4x2f)[_0x4b77[16]](_0x4b77[152]);
                    }
                }
            });
            _0xa2c4x1c++;
        });
        _0xa2c4x2(_0x4b77[162])[_0x4b77[76]](_0x4b77[118], function() {
            var _0xa2c4x30 = _0xa2c4x2(this)[_0x4b77[133]](_0x4b77[160])[_0x4b77[61]](_0x4b77[159])[_0x4b77[127]](_0x4b77[126]);
            _0xa2c4x6[_0x4b77[128] + _0xa2c4x30][_0x4b77[161]]();
        });
        _0xa2c4x2(_0x4b77[164])[_0x4b77[76]](_0x4b77[118], function() {
            var _0xa2c4x30 = _0xa2c4x2(this)[_0x4b77[133]](_0x4b77[160])[_0x4b77[61]](_0x4b77[159])[_0x4b77[127]](_0x4b77[126]);
            _0xa2c4x6[_0x4b77[128] + _0xa2c4x30][_0x4b77[163]]();
        });
        _0xa2c4x2(_0x4b77[158])[_0x4b77[76]](_0x4b77[118], function(_0xa2c4x31) {
            _0xa2c4x31[_0x4b77[165]]();
            var _0xa2c4x30 = _0xa2c4x2(this)[_0x4b77[133]](_0x4b77[160])[_0x4b77[61]](_0x4b77[159])[_0x4b77[127]](_0x4b77[126]);
            if (_0xa2c4x2(this)[_0x4b77[15]](_0x4b77[152])) {
                return false;
            }
            var _0xa2c4x32 = _0xa2c4x2(this)[_0x4b77[121]]()[_0x4b77[61]](_0x4b77[167])[_0x4b77[166]](this);
            _0xa2c4x6[_0x4b77[128] + _0xa2c4x30][_0x4b77[168]](_0xa2c4x32 + 1);
            _0xa2c4x2(this)[_0x4b77[121]]()[_0x4b77[61]](_0x4b77[169])[_0x4b77[22]](_0x4b77[152]);
            _0xa2c4x2(this)[_0x4b77[16]](_0x4b77[152]);
            return false;
        });
    };
    CRUMINA[_0x4b77[170]] = function() {
        function _0xa2c4x37(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0x4b77[171], _0x4b77[172], 0.3, {
                delay: 0.1,
                callback: function() {
                    _0xa2c4x39(_0xa2c4x38);
                }
            });
        }

        function _0xa2c4x39(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0x4b77[174], _0x4b77[175], 0.6, {
                easing: ease[_0x4b77[177]](_0x4b77[176], 1, 0.3)
            });
        }

        function _0xa2c4x3a(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0xa2c4x35 - 60, _0xa2c4x36 + 60, 0.1, {
                callback: function() {
                    _0xa2c4x3b(_0xa2c4x38);
                }
            });
        }

        function _0xa2c4x3b(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0xa2c4x35 + 120, _0xa2c4x36 - 120, 0.3, {
                easing: ease[_0x4b77[177]](_0x4b77[178], 1, 0.3)
            });
        }

        function _0xa2c4x3c(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0x4b77[179], _0x4b77[82], 0.1, {
                easing: ease[_0x4b77[177]](_0x4b77[180], 1, 0.3),
                callback: function() {
                    _0xa2c4x3d(_0xa2c4x38);
                }
            });
        }

        function _0xa2c4x3d(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0x4b77[181], _0x4b77[182], 0.3, {
                callback: function() {
                    _0xa2c4x3e(_0xa2c4x38);
                }
            });
        }

        function _0xa2c4x3e(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0xa2c4x33, _0xa2c4x34, 0.7, {
                easing: ease[_0x4b77[177]](_0x4b77[176], 1, 0.3)
            });
        }

        function _0xa2c4x3f(_0xa2c4x38) {
            _0xa2c4x38[_0x4b77[173]](_0xa2c4x35, _0xa2c4x36, 0.7, {
                delay: 0.1,
                easing: ease[_0x4b77[177]](_0x4b77[176], 2, 0.4)
            });
        }

        function _0xa2c4x40(_0xa2c4x41) {
            _0xa2c4x41[_0x4b77[183]] = _0x4b77[184];
        }

        function _0xa2c4x42(_0xa2c4x41) {
            _0xa2c4x41[_0x4b77[183]] = _0x4b77[185];
        }
        var _0xa2c4x33 = 80;
        var _0xa2c4x34 = 320;
        var _0xa2c4x35 = 80;
        var _0xa2c4x36 = 320;
        var _0xa2c4x43 = document[_0x4b77[187]](_0x4b77[186]);
        var _0xa2c4x44 = document[_0x4b77[187]](_0x4b77[188]);
        var _0xa2c4x45 = document[_0x4b77[187]](_0x4b77[189]);
        var _0xa2c4x46 = new Segment(_0xa2c4x43, _0xa2c4x33, _0xa2c4x34);
        var _0xa2c4x47 = new Segment(_0xa2c4x44, _0xa2c4x35, _0xa2c4x36);
        var _0xa2c4x48 = new Segment(_0xa2c4x45, _0xa2c4x33, _0xa2c4x34);
        var _0xa2c4x49 = document[_0x4b77[187]](_0x4b77[185]);
        var _0xa2c4x4a = document[_0x4b77[187]](_0x4b77[190]);
        var _0xa2c4x4b = true;
        _0xa2c4x49[_0x4b77[192]][_0x4b77[191]] = _0x4b77[193];
        _0xa2c4x4a[_0x4b77[194]] = function() {
            _0xa2c4x40(_0xa2c4x49);
            if (_0xa2c4x4b) {
                _0xa2c4x37(_0xa2c4x46);
                _0xa2c4x3a(_0xa2c4x47);
                _0xa2c4x37(_0xa2c4x48);
            } else {
                _0xa2c4x3c(_0xa2c4x46);
                _0xa2c4x3f(_0xa2c4x47);
                _0xa2c4x3c(_0xa2c4x48);
            }
            _0xa2c4x4b = !_0xa2c4x4b;
            setTimeout(function() {
                _0xa2c4x42(_0xa2c4x49);
            }, 450);
        };
    };
    _0xa2c4x3[_0x4b77[202]](function(_0xa2c4x4c) {
        if (_0xa2c4x4c[_0x4b77[195]] == 27) {
            _0xa2c4x5[_0x4b77[22]](_0x4b77[196]);
            _0xa2c4x2(_0x4b77[197])[_0x4b77[22]](_0x4b77[84]);
            _0xa2c4xc[_0x4b77[198]]({
                "visibility": _0x4b77[193]
            });
            _0xa2c4x2(_0x4b77[200])[_0x4b77[198]]({
                "opacity": _0x4b77[199]
            });
            _0xa2c4x2(_0x4b77[201])[_0x4b77[22]](_0x4b77[84]);
        }
    });
    jQuery(_0x4b77[203])[_0x4b77[76]](_0x4b77[118], function() {
        CRUMINA[_0x4b77[13]]();
        CRUMINA[_0x4b77[83]]();
        return false;
    });
    jQuery(_0x4b77[204])[_0x4b77[76]](_0x4b77[118], function() {
        CRUMINA[_0x4b77[13]]();
        _0xa2c4x5[_0x4b77[22]](_0x4b77[84]);
        return false;
    });
    jQuery(_0x4b77[205])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4x2(_0x4b77[201])[_0x4b77[16]](_0x4b77[84]);
        return false;
    });
    jQuery(_0x4b77[209])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4xc[_0x4b77[61]](_0x4b77[197])[_0x4b77[16]](_0x4b77[84]);
        _0xa2c4xc[_0x4b77[198]]({
            "visibility": _0x4b77[206]
        });
        _0xa2c4x2(_0x4b77[200])[_0x4b77[198]]({
            "opacity": _0x4b77[207]
        });
        setTimeout(function() {
            _0xa2c4xc[_0x4b77[61]](_0x4b77[208])[_0x4b77[87]]();
        }, 100);
        return false;
    });
    jQuery(_0x4b77[210])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4xc[_0x4b77[61]](_0x4b77[197])[_0x4b77[22]](_0x4b77[84]);
        _0xa2c4xc[_0x4b77[198]]({
            "visibility": _0x4b77[193]
        });
        _0xa2c4x2(_0x4b77[200])[_0x4b77[198]]({
            "opacity": _0x4b77[199]
        });
        return false;
    });
    jQuery(_0x4b77[211])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4x2(_0x4b77[201])[_0x4b77[22]](_0x4b77[84]);
        return false;
    });
    jQuery(_0x4b77[213])[_0x4b77[76]](_0x4b77[118], function() {
        CRUMINA[_0x4b77[13]]();
        setTimeout(function() {
            _0xa2c4x2(_0x4b77[212])[_0x4b77[16]](_0x4b77[84]);
        }, 300);
        return false;
    });
    jQuery(_0x4b77[215])[_0x4b77[76]](_0x4b77[118], function() {
        CRUMINA[_0x4b77[13]]();
        setTimeout(function() {
            _0xa2c4x2(_0x4b77[86])[_0x4b77[22]](_0x4b77[84]);
        }, 400);
        setTimeout(function() {
            _0xa2c4x2(_0x4b77[212])[_0x4b77[22]](_0x4b77[84]);
        }, 400);
        setTimeout(function() {
            _0xa2c4x2(_0x4b77[214])[_0x4b77[22]](_0x4b77[84]);
        }, 400);
        return false;
    });
    jQuery(_0x4b77[218])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4x2(_0x4b77[218])[_0x4b77[117]](_0x4b77[217])[_0x4b77[216]](_0x4b77[70])[_0x4b77[87]]();
    });
    jQuery(_0x4b77[222])[_0x4b77[76]](_0x4b77[118], function() {
        jQuery(this)[_0x4b77[220]](_0x4b77[219])[_0x4b77[85]](_0x4b77[119]);
        jQuery(this)[_0x4b77[220]](_0x4b77[221])[_0x4b77[85]](_0x4b77[119]);
    });
    jQuery(_0x4b77[225])[_0x4b77[76]](_0x4b77[118], function() {
        _0xa2c4x2(_0x4b77[224])[_0x4b77[223]]({
            scrollTop: 0
        }, 1200);
        return false;
    });
    _0xa2c4x4[_0x4b77[246]](function() {
        jQuery(function() {
            jQuery(_0x4b77[227])[_0x4b77[228]](function() {
                jQuery(_0x4b77[227])[_0x4b77[117]](_0x4b77[226])[_0x4b77[16]](_0x4b77[84]);
            });
            jQuery(_0x4b77[226])[_0x4b77[229]](function() {
                jQuery(_0x4b77[226])[_0x4b77[22]](_0x4b77[84]);
            });
        });
        _0xa2c4x2(_0x4b77[238])[_0x4b77[76]](_0x4b77[118], function() {
            var _0xa2c4x4d = _0xa2c4x2(this)[_0x4b77[232]]()[_0x4b77[231]](_0x4b77[230]);
            var _0xa2c4x4e = _0xa2c4x2(this)[_0x4b77[133]](_0x4b77[233]);
            var _0xa2c4x4f = _0xa2c4x4e[_0x4b77[61]](_0x4b77[234]);
            _0xa2c4x4f[_0x4b77[66]](function() {
                if (_0xa2c4x4d) {
                    _0xa2c4x2(this)[_0x4b77[236]](_0xa2c4x2(this)[_0x4b77[68]](_0x4b77[235]));
                } else {
                    _0xa2c4x2(this)[_0x4b77[236]](_0xa2c4x2(this)[_0x4b77[68]](_0x4b77[237]));
                }
            });
        });
        if (_0xa2c4x2(_0x4b77[239])[_0x4b77[40]]) {
            CRUMINA[_0x4b77[170]]();
        }
        _0xa2c4xc[_0x4b77[243]]({
            showSpeed: 300,
            hideSpeed: 200,
            trigger: _0x4b77[228],
            animation: _0x4b77[240],
            indicatorFirstLevel: _0x4b77[241],
            indicatorSecondLevel: _0x4b77[242]
        });
        CRUMINA[_0x4b77[34]]();
        CRUMINA[_0x4b77[124]]();
        CRUMINA[_0x4b77[103]]();
        CRUMINA[_0x4b77[89]]();
        CRUMINA.IsotopeSort();
        CRUMINA[_0x4b77[39]]();
        CRUMINA[_0x4b77[49]]();
        _0xa2c4x2(_0x4b77[245])[_0x4b77[244]]();

        CRUMINA[_0x4b77[46]]();
        CRUMINA[_0x4b77[28]]();
        CRUMINA[_0x4b77[67]]();
        CRUMINA[_0x4b77[59]]();
        CRUMINA[_0x4b77[77]]();
    });
    _0xa2c4x2(window)[_0x4b77[76]](_0x4b77[247], function() {
        window[_0x4b77[248]](CRUMINA[_0x4b77[28]]);
    });
})(jQuery);